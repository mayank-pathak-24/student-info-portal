
import './App.css'

import { BrowserRouter,Route,Routes } from 'react-router-dom'
import Signup from './components/Signup'
import Read from './components/Read'
import Navbar from './components/Navbar'
import Login from './components/Login'
function App() {
 

  return (
   
      <div className='app'>
        <BrowserRouter>
       <Login/>
        <Routes>
          <Route path="signup" element={<Signup/>}></Route>
          <Route exact path="/read" element={<Read/>}></Route>
        </Routes>

        </BrowserRouter>
        
      </div>
    
  )
}

export default App
