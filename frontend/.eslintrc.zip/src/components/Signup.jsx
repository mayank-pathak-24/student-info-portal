import { useState } from "react";



const Signup = () => {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [age, setAge] = useState("")
  const [password, setPassword] = useState("")
  const [contactNumber, setContactNumber] = useState("")


  console.log(name, email, age, contactNumber, password);
  const handleSubmit = async (e) => {
    e.preventDefault();
    const addUser = { name, email, contactNumber, age, password };
    const responce = await fetch("http://localhost:5010/signup", {
      method: "POST",
      body: JSON.stringify(addUser),
      headers: {
        "Content-Type": "application/json",
      }
    })
    const result = await responce.json()

    if (!responce.ok)
      console.log(result.error);


    if (responce.ok)
      console.log(result);

  }
  return (
    <div className="container my-2">
      <h2 className="text-center">Enter the data</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Email address</label>
          <input type="email" className="form-control"

            value={email}
            onChange={(e) => setEmail(e.target.value)} />

        </div>

        <div className="mb-3">
          <label className="form-label">Age</label>
          <input type="number" className="form-control"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input type="password" className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="form-label">Phone Number</label>
          <input type="number" className="form-control"
            value={contactNumber}
            onChange={(e) => setContactNumber(e.target.value)}
          />
        </div>

        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  )
}

export default Signup;