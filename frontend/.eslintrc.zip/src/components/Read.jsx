

const Read=()=>
{
    return(
        <div>
            Read
        </div>
    )
}
export default Read;