import { useState } from "react";

import { Link } from 'react-router-dom';

const Login = () => {
    const style={
        margin :'250px'
    }
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    async function submit(e) {
        e.preventDefault();
        try {
            const user = { email, password };
            const response = await fetch("http://localhost:5010/login", {
                method: "POST",
                body: JSON.stringify(user),
                headers: {
                    "Content-Type": "application/json",
                }
            });
            const result = await response.json();
            console.log(result);
        } catch (error) {
            console.log(error);
        }
    }

    return (
        <div className="Login" style={style}>
            <h1>Login</h1>
            <form onSubmit={submit}>
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="abc@gmail.com"
                    required
                />
                <br />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="abc@12Ad"
                    required
                />
                <br />
                
                <input
                    
                    type="submit"
                    value="Login"
                />
                
            </form>
            <p>Or</p>
            <p>Dont have an account? <Link to="/signup">Signup here</Link></p>
        </div>
    );
}

export default Login;


